# import threading
# import random


# def collision_check(A, B):
#     if A.top < B.bottom and B.top < A.bottom and A.left < B.right and B.left < A.right:
#         return True

#     else:
#         return False


# from pygame.locals import QUIT, Rect

# x = random.randint(0, 20)
# y = random.randint(0, 20)

# x1 = random.randint(0, 20)
# y1 = random.randint(0, 20)

# A = Rect(x, y, 10, 10)
# B = Rect(x1, y1, 10, 10)

# print(collision_check(A, B))


# class snack:
#     def __init__(self, str, rect):
#         self.name = str
#         self.snackrect = rect

#     def get_rect(self):
#         return self.snackrect


# import cv2
# import numpy as np


# def collision_check(A, B):
#     if A[1] < B[3] and B[1] < A[3] and A[0] < B[2] and B[0] < A[2]:
#         return True
#     else:
#         return False


# class Rectangle:
#     def __init__(self, x, y, w, h):
#         self.x = x
#         self.y = y
#         self.w = w
#         self.h = h

#     def get_rect(self):
#         return (self.x, self.y, self.w, self.h)

#     def draw(self, image):
#         cv2.rectangle(
#             image, (self.x, self.y), (self.x + self.w, self.y + self.h), (0, 0, 255), 2
#         )


# image = np.zeros((480, 640, 3), np.uint8)
# rect1 = Rectangle(100, 100, 50, 50)
# rect2 = Rectangle(150, 150, 50, 50)

# while True:
#     image.fill(0)
#     rect1.draw(image)
#     rect2.draw(image)
#     cv2.imshow("image", image)
#     key = cv2.waitKey(10)
#     if key == ord("q"):
#         break

#     if collision_check(rect1.get_rect(), rect2.get_rect()):
#         print("collision")
#         rect2 = None

# cv2.destroyAllWindows()
